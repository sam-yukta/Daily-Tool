package com.info.services;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.UnsupportedEncodingException;
import java.net.HttpURLConnection;
import java.net.MalformedURLException;
import java.net.URL;
import java.net.URLEncoder;

//import org.json.JSONObject;
//import org.json.JSONException;

public class getIPV6Address {
	
	private static final String baseBaiduUrl="http://sctcore-po-k1i.sys.comcast.net:8084/Scout_Core_Services-X/api/deviceservice/getAllWifiInfo?appKey=QA_PROD&mac=";
	
	 public static String getipv6Info(String cmmac)
	    {
		 System.out.println("Inside getipv6Info");
	        String jsonResult=getipv6JsonString(cmmac);
	        System.out.println("jsonResult in getIPV6Address is" +jsonResult);
	        String ipv6list = null;
	        String ipv6 = null;
			
		/*	try {
				JSONObject json1 = new JSONObject(jsonResult);
				ipv6list=json1.getJSONArray("deviceResponseList").getJSONObject(0).getString("cmInfo");
				JSONObject json2 = new JSONObject(ipv6list);
				ipv6=json2.getString("ip");
				System.out.println("ipv6 from response is-----"+ipv6);
			} catch (JSONException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
				
			} 
	       // Root weatherInfoObject=toEntity(jsonResult);
	        
	    }*/
	    
	    //Covert json string to class object
	  /*  private static Root toEntity(String jsonString)
	    {
	        try{
	            Gson gson = new GsonBuilder().create();
	            Root weatherInfo = gson.fromJson(jsonString, Root.class);            
	            return weatherInfo;
	        }
	        catch(JsonSyntaxException ex)
	        {
	            ex.printStackTrace();
	            return null;
	        }*/
	        return jsonResult;
	    }
	
	//Get the ipv6address of the specific cm mac
    private static String getipv6JsonString(String cmmac) throws RuntimeException{  
        
        //define a variable to store the weather api url and set beijing as it's default value
        String baiduUrl = baseBaiduUrl; //default value hard-coded 'beijing' 
                                                  //should be stored in config file
  
        try {
            if(cmmac!=null && cmmac!="")
                baiduUrl = baseBaiduUrl+URLEncoder.encode(cmmac, "utf-8");                    
        } catch (UnsupportedEncodingException e1) {               
            e1.printStackTrace();                     
        }  

        StringBuilder strBuf = new StringBuilder();  
        
        HttpURLConnection conn=null;
        BufferedReader reader=null;
        try{  
            //Declare the connection to weather api url
            URL url = new URL(baiduUrl);  
            conn = (HttpURLConnection)url.openConnection();  
            conn.setRequestMethod("GET");
            conn.setRequestProperty("Accept", "application/json");
            
            
            if (conn.getResponseCode() != 200) {
                throw new RuntimeException("HTTP GET Request Failed with Error code : "
                              + conn.getResponseCode());
            }
            
            //Read the content from the defined connection
            //Using IO Stream with Buffer raise highly the efficiency of IO
	        reader = new BufferedReader(new InputStreamReader(conn.getInputStream(),"utf-8"));
            String output = null;  
            while ((output = reader.readLine()) != null)  
                strBuf.append(output);  
        }catch(MalformedURLException e) {  
            e.printStackTrace();   
        }catch(IOException e){  
            e.printStackTrace();   
        }
        finally
        {
            if(reader!=null)
            {
                try {
                    reader.close();
                } catch (IOException e) {
                    e.printStackTrace();
                }
            }
            if(conn!=null)
            {
                conn.disconnect();
            }
        }

        return strBuf.toString();  
    }
	
	

}
