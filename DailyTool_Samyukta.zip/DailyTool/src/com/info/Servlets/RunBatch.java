package com.info.Servlets;

import java.io.IOException;

public class RunBatch {

RunBatch()
{
	//getIPV6Address output=new getIPV6Address();
	//String ip=output.getipaddress();
	//System.out.println("Inside Run Batch"+ip);
	String path="cmd /c start C:\\Users\\smurth004c\\Desktop\\CFG3\\Scripts\\xfinity_wifi.bat";
	Runtime rn=Runtime.getRuntime();
	try {
		Process pr=rn.exec(path);
	} catch (IOException e) {
		// TODO Auto-generated catch block
		e.printStackTrace();
	}	

}

}
