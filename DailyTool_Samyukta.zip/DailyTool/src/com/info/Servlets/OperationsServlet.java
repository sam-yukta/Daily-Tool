package com.info.Servlets;

/*Author Samyukta*/

import java.io.File;
import java.io.FileWriter;
import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.ServletContext;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.info.services.getIPV6Address;

/* Servlet implementation class Operations*/

@WebServlet("/OperationsServlet")
public class OperationsServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public OperationsServlet() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		String cmmac=request.getParameter("cmmac");
		System.out.println("inside doGet");
		String result = getIPV6Address.getipv6Info("5c:e3:0e:51:c7:29");
		
		System.out.println("Http response-------------"+result);
		System.out.println("cm mac from GET Method"+cmmac);
		
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		String path=null;
	    StringBuilder newpath;
		response.setContentType("text/html;charset=UTF-8");
		PrintWriter out=response.getWriter();
		String ipaddress=request.getParameter("ip_address");
		System.out.println("xfinity wifi Ip address from POST Method is"+ipaddress);
		String ssid_two=request.getParameter("ssid_2.4");
		System.out.println("2.4 ssid is from POST Method "+ssid_two);
		String ssid_five=request.getParameter("ssid_5");
		System.out.println("5 ssid is from POST Method "+ssid_five);
		String prodip=request.getParameter("SNMP_ip_address");
		System.out.println("snmp ip address is from POST Method "+prodip);
		String image=request.getParameter("Image");
		System.out.println("xb3 Image is from POST Method "+image);
		String xf3eponmac=request.getParameter("xf3_epon_mac");
		System.out.println("xf3 ip address is from POST Method "+xf3eponmac);
		String xf3image=request.getParameter("xf3_Image");
		System.out.println("xf3 Image is from POST Method "+xf3image);
		String qascript=request.getParameter("qa");
		String prodscript=request.getParameter("prod");
		String prodsnmpupgrade=request.getParameter("prodsnmpupgrade");
		String xf3cfg3upgrade=request.getParameter("xf3cfg3upgrade");
		System.out.println("qascript is from POST Menthod"+qascript);
		System.out.println("prodscript is from POST Menthod"+prodscript);
		System.out.println("xf3cfg3upgrade script is from POST Menthod"+xf3cfg3upgrade);
		
		if (qascript != null)
		{
			path="sh //root//qaxfinitywifi.sh ";
		    newpath=new StringBuilder().append(path).append(ipaddress).append(" ").append(ssid_two).append(" ").append(ssid_five);
		}
		else if(prodscript != null)
		{
			path="sh //root//prodxfinitywifi.sh ";
			newpath=new StringBuilder().append(path).append(ipaddress).append(" ").append(ssid_two).append(" ").append(ssid_five);
		}
		else if(xf3cfg3upgrade != null)
		{
			path="sh //root//xf3cfg3upgrade.sh ";
			newpath=new StringBuilder().append(path).append(xf3eponmac).append(" ").append(xf3image);
		}
		else 
		{
			path="sh //root//prodsnmpupgrade.sh ";
			newpath=new StringBuilder().append(path).append(prodip).append(" ").append(image);
		}
		
	
		
		System.out.println("Path is "+path);
		System.out.println("concatenated string "+ newpath.toString());
		Runtime rn=Runtime.getRuntime();
		
		
		try {
			Process pr=rn.exec(newpath.toString());	
			int success = pr.waitFor();
			System.out.println("Output of success"+ success);
			out.println("Done!");
			pr.destroy();
	       
		}catch (InterruptedException e) {
	        	out.println("Exception "+e);
	        	} 
	    }
	}
	



